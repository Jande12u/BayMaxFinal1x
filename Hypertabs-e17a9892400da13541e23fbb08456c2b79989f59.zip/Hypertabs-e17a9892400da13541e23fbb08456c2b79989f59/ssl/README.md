# SSL config

To enable SSL when using a provider that does not provide them, place your certificates in the SSL folder.

The certificate should be named `cert.pem` and the private key named `key.pem`